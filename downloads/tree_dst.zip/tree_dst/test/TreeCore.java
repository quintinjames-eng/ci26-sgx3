package test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import tree.*;
import java.util.List;
import java.util.Arrays;

public class TreeCore{
    private BinarySearchTree<Integer> bst;
    private AVLTree<Integer> avl;

    @Before
    public void setUp() {
        bst = new BinarySearchTree<>();
        avl = new AVLTree<>();
    }

    @Test
    public void testInsertAndContains() {
        int[] data = {50, 30, 70, 20, 40};
        for (int val : data) {
            bst.insert(val);
            avl.insert(val);
        }

        assertTrue(bst.contains(50));
        assertTrue(avl.contains(20));
        assertFalse(bst.contains(100));
        assertFalse(avl.contains(1));
    }

    @Test
    public void testInorderTraversal() {
        List<Integer> inputs = Arrays.asList(15, 10, 20, 8, 12);
        for (int i : inputs) bst.insert(i);

        // Inorder should always be sorted
        List<Integer> expected = Arrays.asList(8, 10, 12, 15, 20);
        assertEquals(expected, bst.inorder());
    }

    @Test
    public void testRemoveLeaf() {
        bst.insert(10);
        bst.insert(5);
        bst.remove(5);
        assertFalse(bst.contains(5));
        assertEquals(0, bst.height());
    }

    @Test
    public void testRemoveTwoChildrenHibbard() {
        // This tests the "Successor" logic we discussed
        bst.insert(50);
        bst.insert(30);
        bst.insert(70);
        bst.insert(60);
        bst.insert(80);

        bst.remove(70); // 70 has two children: 60 and 80
        assertTrue(bst.contains(60));
        assertTrue(bst.contains(80));
        assertFalse(bst.contains(70));
        
        // Ensure structure is maintained
        assertEquals(Arrays.asList(30, 50, 60, 80), bst.inorder());
    }
}