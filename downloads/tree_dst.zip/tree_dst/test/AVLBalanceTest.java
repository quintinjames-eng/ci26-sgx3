package test;

import static org.junit.Assert.*;
import org.junit.Test;
import tree.*;

public class AVLBalanceTest{

    @Test
    public void testSortedInputBalance() {
        AVLTree<Integer> avl = new AVLTree<>();
        // Standard BST would have height 9
        // AVL should have height ~3
        for (int i = 1; i <= 10; i++) {
            avl.insert(i);
        }

        assertTrue("AVL height should be logarithmic", avl.height() <= 4);
    }

    @Test
    public void testDoubleRotationLR() {
        AVLTree<Integer> avl = new AVLTree<>();
        avl.insert(30); // Root
        avl.insert(10); // Left
        avl.insert(20); // Left-Right (Causes bend)

        // After LR rotation, 20 should be the new root
        assertEquals(Integer.valueOf(20), avl.levelOrder().get(0));
        assertEquals(0, avl.height()); // Height of 3 nodes balanced is 1 (level 0, 1) 
                                       // depending on your height implementation
    }

    @Test
    public void testEmptyAndSingleNode() {
        AVLTree<Integer> avl = new AVLTree<>();
        assertEquals(-1, avl.height());
        assertNull(avl.findMin());
        
        avl.insert(100);
        assertEquals(0, avl.height());
        avl.remove(100);
        assertFalse(avl.contains(100));
    }
}