# tree_dst: Tree Data Structures & Analysis

## Setup
1. Compile the source: `javac -d bin src/**/*.java`
2. Run the benchmarking tool: `java -cp bin app.Main`

## Project Structure
- `tree/`: Generic `BinarySearchTree` and `AVLTree` implementations.
- `bench/`: Metrics tracking and `DatasetGenerator`.
- `app/`: CLI Entry point.
- `test/`: JUnit 4 test suite.

## Known Constraints
- **Recursion Limit**: For standard BSTs with sorted input, N is capped at ~9250 to prevent StackOverflowError on default JVM settings.
- **Duplicates**: The system uses a "Reject Duplicate" policy to maintain set integrity.

## Results Summary
The AVL Tree consistently maintains a height of O(log N), even in worst-case sorted distributions, whereas the BST degenerates to O(N). This results in a ~100x performance improvement in search comparisons for N=2000.

## CLI Examples (Strings to put in the "Run Arguments" box)
Basic Random BST	--n=1000 --dist=random --tree=bst
Worst-case BST	--n=1500 --dist=sorted --tree=bst
Worst-case AVL	--n=5000 --dist=sorted --tree=avl

First draft of ReadMe assembled by Google Gemini and revised by Quintin Ampofo.
Google Gemini was used to troubleshoot all code in tree_dst. 


