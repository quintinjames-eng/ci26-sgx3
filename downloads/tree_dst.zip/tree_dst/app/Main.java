package app;
import tree.*;
import bench.*;

public class Main {
    public static void main(String[] args) {
        // Default values
        int n = 1000;
        String dist = "random";
        String treeType = "bst";

        // Simple Manual Parser
        for (String arg : args) {
            if (arg.startsWith("--n=")) {
                n = Integer.parseInt(arg.substring(4));
            } else if (arg.startsWith("--dist=")) {
                dist = arg.substring(7).toLowerCase();
            } else if (arg.startsWith("--tree=")) {
                treeType = arg.substring(7).toLowerCase();
            }
        }

        runExperiment(n, dist, treeType);
    }

    public static void runExperiment(int n, String dist, String type) {
        Integer[] data = DatasetGenerator.generate(n, dist);
        
        if (type.equalsIgnoreCase("AVL")){
           AVLTree<Integer> avl = new AVLTree<>();
           long start = System.currentTimeMillis();
           
           // Bulk Insert (The "Build" Workload)
           for (int val : data) {
               avl.insert(val);
           }
           
           long end = System.currentTimeMillis();
   
           // Package the Metrics
           Metrics m = new Metrics();
           m.treeType = type;
           m.distribution = dist;
           m.n = n;
           m.elapsedMs = (end - start);
           m.comparisons = avl.getComparisons();
           m.height = avl.height();
           m.rotations = avl.getTotalRotations();
           
           m.printSummary();
        }
        
        else{
           BinarySearchTree<Integer> bst = new BinarySearchTree<>();
           long start = System.currentTimeMillis();
           
           // Bulk Insert (The "Build" Workload)
           for (int val : data) {
               bst.insert(val);
           }
           
           long end = System.currentTimeMillis();
   
           // Package the Metrics
           Metrics m = new Metrics();
           m.treeType = type;
           m.distribution = dist;
           m.n = n;
           m.elapsedMs = (end - start);
           m.comparisons = bst.getComparisons();
           m.height = bst.height();
           
           m.printSummary();
        }
    }
}