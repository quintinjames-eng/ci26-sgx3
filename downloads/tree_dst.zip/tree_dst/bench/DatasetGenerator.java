package bench;
import java.util.*;

public class DatasetGenerator {
    public static Integer[] generate(int n, String dist) {
        Integer[] arr = new Integer[n];
        for (int i = 0; i < n; i++) arr[i] = i;

        switch (dist.toLowerCase()) {
            case "sorted": 
                return arr;
            case "reverse":
                Collections.reverse(Arrays.asList(arr));
                return arr;
            case "random":
                List<Integer> list = Arrays.asList(arr);
                Collections.shuffle(list);
                return list.toArray(new Integer[0]);
            default:
                return arr;
        }
    }
}