package bench;

public class Metrics {
    public String treeType;
    public String distribution;
    public int n;
    public long elapsedMs;
    public long comparisons;
    public int height;
    // AVL specific
    public int rotations;

    public void printSummary() {
        System.out.println("--- Results for " + treeType + " (" + distribution + ") ---");
        System.out.println("Size (N): " + n);
        System.out.println("Time: " + elapsedMs + " ms");
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Final Height: " + height);
        if (treeType.equals("AVL")) {
            System.out.println("Total Rotations: " + rotations);
        }
        System.out.println("------------------------------------------");
    }
}