package tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * A generic Binary Search Tree (BST).
 * Supports insert, contains, remove, findMin, findMax,
 * height, and four traversal orders.
 * Duplicate keys are ignored on insert.
 *
 * @param <T> the type of key stored, must be Comparable
 */
public class BinarySearchTree<T extends Comparable<T>> {

    private BSTNode<T> root;
    private long comparisons; // for use in metrics module

    /** Constructs an empty BST. */
    public BinarySearchTree() {
        root        = null;
        comparisons = 0;
    }

    // ─────────────────────────────────────────────────────────
    // INSERT
    // ─────────────────────────────────────────────────────────

    /**
     * Inserts a key into the BST.
     * Duplicate keys are silently ignored.
     * @param key the value to insert
     */
    public void insert(T key) {
        root = insertRec(root, key);
    }

    private BSTNode<T> insertRec(BSTNode<T> node, T key) { // helper method
        if (node == null) 
         return new BSTNode<>(key);

        comparisons++;
        int cmp = key.compareTo(node.key);

        if (cmp < 0) 
         node.left  = insertRec(node.left,  key);
        else if (cmp > 0) 
         node.right = insertRec(node.right, key);
        // IF cmp == 0 means duplicate, so do nothing
        // this is why there's no "else" statement

        return node;
    }

    // ─────────────────────────────────────────────────────────
    // CONTAINS
    // ─────────────────────────────────────────────────────────

    /**
     * Returns true if the key exists in the BST.
     * @param key the value to search for
     * @return true if found, false otherwise
     */
    public boolean contains(T key) {
        return containsRec(root, key);
    }

    private boolean containsRec(BSTNode<T> node, T key) {
        if (node == null) return false;

        comparisons++;
        int cmp = key.compareTo(node.key);

        if      (cmp < 0) return containsRec(node.left,  key);
        else if (cmp > 0) return containsRec(node.right, key);
        else              return true;
    }

    // ─────────────────────────────────────────────────────────
    // REMOVE
    // ─────────────────────────────────────────────────────────

    /**
     * Removes a key from the BST if it exists.
     * Uses Hibbard deletion for the two-child case
     * (replace with inorder successor).
     * @param key the value to remove
     */
    public void remove(T key) {
        root = removeRec(root, key);
    }

    private BSTNode<T> removeRec(BSTNode<T> node, T key) {
        if (node == null) return null;

        comparisons++;
        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left  = removeRec(node.left,  key);
        } else if (cmp > 0) {
            node.right = removeRec(node.right, key);
        } else {
            // Found the node to remove — three cases

            // Case 1: leaf node
            if (node.left == null && node.right == null) return null;

            // Case 2: one child
            if (node.left  == null) return node.right;
            if (node.right == null) return node.left;

            // Case 3: two children — replace with inorder successor
            BSTNode<T> successor = findMinNode(node.right); // finds smallest node in right subtree
            node.key   = successor.key; // copies successor's key to current node
            node.right = removeRec(node.right, successor.key); // deletes successor from right subtree
        }

        return node;
    }

    // ─────────────────────────────────────────────────────────
    // FIND MIN / MAX
    // ─────────────────────────────────────────────────────────

    /**
     * Returns the smallest key in the BST.
     * @return the minimum key, or null if the tree is empty
     */
    public T findMin() {
        if (root == null) return null;
        return findMinNode(root).key;
    }

    private BSTNode<T> findMinNode(BSTNode<T> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    /**
     * Returns the largest key in the BST.
     * @return the maximum key, or null if the tree is empty
     */
    public T findMax() {
        if (root == null) return null;
        BSTNode<T> node = root;
        while (node.right != null) node = node.right;
        return node.key;
    }

    // ─────────────────────────────────────────────────────────
    // HEIGHT
    // ─────────────────────────────────────────────────────────

    /**
     * Returns the height of the BST.
     * An empty tree has height -1. A single node has height 0.
     * @return the height of the tree
     */
    public int height() {
        return heightRec(root);
    }

    private int heightRec(BSTNode<T> node) {
        if (node == null) return -1;
        return 1 + Math.max(heightRec(node.left), heightRec(node.right));
    }

    // ─────────────────────────────────────────────────────────
    // TRAVERSALS
    // ─────────────────────────────────────────────────────────

    /**
     * Returns a list of all keys in inorder (left, root, right).
     * For a BST this produces keys in ascending sorted order.
     * @return list of keys in inorder
     */
    public List<T> inorder() {
        List<T> result = new ArrayList<>();
        inorderRec(root, result);
        return result;
    }

    private void inorderRec(BSTNode<T> node, List<T> result) {
        if (node == null) return;
        inorderRec(node.left,  result);
        result.add(node.key);
        inorderRec(node.right, result);
    }

    /**
     * Returns a list of all keys in preorder (root, left, right).
     * @return list of keys in preorder
     */
    public List<T> preorder() {
        List<T> result = new ArrayList<>();
        preorderRec(root, result);
        return result;
    }

    private void preorderRec(BSTNode<T> node, List<T> result) {
        if (node == null) return;
        result.add(node.key);
        preorderRec(node.left,  result);
        preorderRec(node.right, result);
    }

    /**
     * Returns a list of all keys in postorder (left, right, root).
     * @return list of keys in postorder
     */
    public List<T> postorder() {
        List<T> result = new ArrayList<>();
        postorderRec(root, result);
        return result;
    }

    private void postorderRec(BSTNode<T> node, List<T> result) {
        if (node == null) return;
        postorderRec(node.left,  result);
        postorderRec(node.right, result);
        result.add(node.key);
    }

    /**
     * Returns a list of all keys in level-order (BFS, top to bottom).
     * @return list of keys in level-order
     */
    public List<T> levelOrder() {
        List<T>          result = new ArrayList<>();
        Queue<BSTNode<T>> queue  = new LinkedList<>();

        if (root == null) return result;

        queue.add(root);
        while (!queue.isEmpty()) {
            BSTNode<T> node = queue.poll();
            result.add(node.key);
            if (node.left  != null) queue.add(node.left);
            if (node.right != null) queue.add(node.right);
        }

        return result;
    }

    // ─────────────────────────────────────────────────────────
    // VALIDATION
    // ─────────────────────────────────────────────────────────

    /**
     * Verifies the BST order property holds for the entire tree.
     * Every left descendant must be smaller and every right
     * descendant must be larger than their ancestor.
     * @return true if the BST property holds, false otherwise
     */
    public boolean isValidBST() {
        return isValidRec(root, null, null);
    }

    private boolean isValidRec(BSTNode<T> node, T min, T max) {
        if (node == null) return true;

        if (min != null && node.key.compareTo(min) <= 0) return false;
        if (max != null && node.key.compareTo(max) >= 0) return false;

        return isValidRec(node.left,  min, node.key)
            && isValidRec(node.right, node.key, max);
    }

    // ─────────────────────────────────────────────────────────
    // METRICS HELPERS
    // ─────────────────────────────────────────────────────────

    /**
     * Returns the total number of comparisons made since construction.
     * @return comparison count
     */
    public long getComparisons() {
        return comparisons;
    }

    /** Resets the comparison counter to zero. */
    public void resetComparisons() {
        comparisons = 0;
    }

    /**
     * Returns true if the tree is empty.
     * @return true if empty
     */
    public boolean isEmpty() {
        return root == null;
    }
    
    public static void main(String[] args) {
    BinarySearchTree<Integer> tree = new BinarySearchTree<>();
    // Creating a small tree
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);

    System.out.println("Inorder (Should be 3, 5, 7, 10, 15): " + tree.inorder());
    System.out.println("Level-order (Should be 10, 5, 15, 3, 7): " + tree.levelOrder());
    System.out.println("Tree Height: " + tree.height());
}
}