package tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * A generic AVL Tree (height-balanced BST).
 * Maintains |balance factor| <= 1 at every node via
 * LL, RR, LR, and RL rotations on insert and remove.
 * Duplicate keys are silently ignored on insert.
 *
 * @param <T> the type of key stored, must be Comparable
 */
public class AVLTree<T extends Comparable<T>>{

    private AVLNode<T> root;
    private int comparisons;
    private int rotationsLL;
    private int rotationsRR;
    private int rotationsLR;
    private int rotationsRL;

    /** Constructs an empty AVL tree. */
    public AVLTree() {
        root         = null;
        comparisons  = 0;
        rotationsLL  = 0;
        rotationsRR  = 0;
        rotationsLR  = 0;
        rotationsRL  = 0;
    }

    // ─────────────────────────────────────────────────────────
    // HEIGHT & BALANCE HELPERS
    // ─────────────────────────────────────────────────────────

    private int height(AVLNode<T> node) {
        return node == null ? -1 : node.height;
    }

    private void updateHeight(AVLNode<T> node) {
        node.height = 1 + Math.max(height(node.left), height(node.right));
    }

    private int balanceFactor(AVLNode<T> node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    // ─────────────────────────────────────────────────────────
    // ROTATIONS
    // ─────────────────────────────────────────────────────────

    /**
     * Performs a right rotation (LL case).
     * @param z the unbalanced node
     * @return the new root of this subtree after rotation
     */
    private AVLNode<T> rotateRight(AVLNode<T> z) {
        AVLNode<T> y = z.left;
        AVLNode<T> T2 = y.right;

        y.right = z;
        z.left  = T2;

        updateHeight(z);
        updateHeight(y);

        rotationsLL++;
        return y;
    }

    /**
     * Performs a left rotation (RR case).
     * @param z the unbalanced node
     * @return the new root of this subtree after rotation
     */
    private AVLNode<T> rotateLeft(AVLNode<T> z) {
        AVLNode<T> y  = z.right;
        AVLNode<T> T2 = y.left;

        y.left  = z;
        z.right = T2;

        updateHeight(z);
        updateHeight(y);

        rotationsRR++;
        return y;
    }

    // ─────────────────────────────────────────────────────────
    // REBALANCE
    // ─────────────────────────────────────────────────────────

    /**
     * Checks the balance factor at a node and applies the
     * appropriate rotation if needed.
     * @param node the node to rebalance
     * @return the new root of this subtree after rebalancing
     */
    private AVLNode<T> rebalance(AVLNode<T> node) {
        updateHeight(node);
        int bf = balanceFactor(node);

        // LL case
        if (bf == 2 && balanceFactor(node.left) >= 0) {
            return rotateRight(node);
        }

        // LR case
        if (bf == 2 && balanceFactor(node.left) < 0) {
            System.out.println("Performing LR Rotation on node: " + node.key);
            rotationsLL--;
            node.left = rotateLeft(node.left);
            rotationsRR--;
            rotationsLR++;
            return rotateRight(node);
        }

        // RR case
        if (bf == -2 && balanceFactor(node.right) <= 0) {
            return rotateLeft(node);
        }

        // RL case
        if (bf == -2 && balanceFactor(node.right) > 0) {
            rotationsRR--;
            node.right = rotateRight(node.right);
            rotationsLL--;
            rotationsRL++;
            return rotateLeft(node);
        }

        return node;
    }

    // ─────────────────────────────────────────────────────────
    // INSERT
    // ─────────────────────────────────────────────────────────

    /**
     * Inserts a key into the AVL tree.
     * Duplicate keys are silently ignored.
     * @param key the value to insert
     */
    public void insert(T key) {
        root = insertRec(root, key);
    }

    private AVLNode<T> insertRec(AVLNode<T> node, T key) {
        if (node == null) return new AVLNode<>(key);

        comparisons++;
        int cmp = key.compareTo(node.key);

        if      (cmp < 0) node.left  = insertRec(node.left,  key);
        else if (cmp > 0) node.right = insertRec(node.right, key);
        // cmp == 0, it's a duplicate, so ignore

        return rebalance(node);
    }

    // ─────────────────────────────────────────────────────────
    // CONTAINS
    // ─────────────────────────────────────────────────────────

    /**
     * Returns true if the key exists in the AVL tree.
     * @param key the value to search for
     * @return true if found, false otherwise
     */
    public boolean contains(T key) {
        return containsRec(root, key);
    }

    private boolean containsRec(AVLNode<T> node, T key) {
        if (node == null) return false;

        comparisons++;
        int cmp = key.compareTo(node.key);

        if      (cmp < 0) return containsRec(node.left,  key);
        else if (cmp > 0) return containsRec(node.right, key);
        else              return true;
    }

    // ─────────────────────────────────────────────────────────
    // REMOVE
    // ─────────────────────────────────────────────────────────

    /**
     * Removes a key from the AVL tree if it exists.
     * Uses inorder successor for two-child case.
     * Rebalances on the way back up after removal.
     * @param key the value to remove
     */
    public void remove(T key) {
        root = removeRec(root, key);
    }

    private AVLNode<T> removeRec(AVLNode<T> node, T key) {
        if (node == null) return null;

        comparisons++;
        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left  = removeRec(node.left,  key);
        } else if (cmp > 0) {
            node.right = removeRec(node.right, key);
        } else {
            // Case 1: leaf
            if (node.left == null && node.right == null) return null;

            // Case 2: one child
            if (node.left  == null) return node.right;
            if (node.right == null) return node.left;

            // Case 3: two children — replace with inorder successor
            AVLNode<T> successor = findMinNode(node.right);
            node.key   = successor.key;
            node.right = removeRec(node.right, successor.key);
        }

        return rebalance(node);
    }

    // ─────────────────────────────────────────────────────────
    // FIND MIN / MAX
    // ─────────────────────────────────────────────────────────

    /**
     * Returns the smallest key in the AVL tree.
     * @return the minimum key, or null if empty
     */
    public T findMin() {
        if (root == null) return null;
        return findMinNode(root).key;
    }

    private AVLNode<T> findMinNode(AVLNode<T> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    /**
     * Returns the largest key in the AVL tree.
     * @return the maximum key, or null if empty
     */
    public T findMax() {
        if (root == null) return null;
        AVLNode<T> node = root;
        while (node.right != null) node = node.right;
        return node.key;
    }

    // ─────────────────────────────────────────────────────────
    // HEIGHT
    // ─────────────────────────────────────────────────────────

    /**
     * Returns the height of the AVL tree.
     * An empty tree has height -1. A single node has height 0.
     * @return the height of the tree
     */
    public int height() {
        return height(root);
    }

    // ─────────────────────────────────────────────────────────
    // TRAVERSALS
    // ─────────────────────────────────────────────────────────

    /**
     * Returns all keys in inorder (ascending sorted order).
     * @return list of keys in inorder
     */
    public List<T> inorder() {
        List<T> result = new ArrayList<>();
        inorderRec(root, result);
        return result;
    }

    private void inorderRec(AVLNode<T> node, List<T> result) {
        if (node == null) return;
        inorderRec(node.left,  result);
        result.add(node.key);
        inorderRec(node.right, result);
    }

    /**
     * Returns all keys in preorder (root, left, right).
     * @return list of keys in preorder
     */
    public List<T> preorder() {
        List<T> result = new ArrayList<>();
        preorderRec(root, result);
        return result;
    }

    private void preorderRec(AVLNode<T> node, List<T> result) {
        if (node == null) return;
        result.add(node.key);
        preorderRec(node.left,  result);
        preorderRec(node.right, result);
    }

    /**
     * Returns all keys in postorder (left, right, root).
     * @return list of keys in postorder
     */
    public List<T> postorder() {
        List<T> result = new ArrayList<>();
        postorderRec(root, result);
        return result;
    }

    private void postorderRec(AVLNode<T> node, List<T> result) {
        if (node == null) return;
        postorderRec(node.left,  result);
        postorderRec(node.right, result);
        result.add(node.key);
    }

    /**
     * Returns all keys in level-order (BFS, top to bottom).
     * @return list of keys in level-order
     */
    public List<T> levelOrder() {
        List<T>           result = new ArrayList<>();
        Queue<AVLNode<T>> queue  = new LinkedList<>();

        if (root == null) return result;

        queue.add(root);
        while (!queue.isEmpty()) {
            AVLNode<T> node = queue.poll();
            result.add(node.key);
            if (node.left  != null) queue.add(node.left);
            if (node.right != null) queue.add(node.right);
        }

        return result;
    }

    // ─────────────────────────────────────────────────────────
    // VALIDATION
    // ─────────────────────────────────────────────────────────

    /**
     * Verifies the BST order property holds for the entire tree.
     * @return true if BST property holds, false otherwise
     */
    public boolean isValidBST() {
        return isValidBSTRec(root, null, null);
    }

    private boolean isValidBSTRec(AVLNode<T> node, T min, T max) {
        if (node == null) return true;
        if (min != null && node.key.compareTo(min) <= 0) return false;
        if (max != null && node.key.compareTo(max) >= 0) return false;
        return isValidBSTRec(node.left,  min, node.key)
            && isValidBSTRec(node.right, node.key, max);
    }

    /**
     * Verifies the AVL balance invariant — |bf| <= 1 at every node.
     * @return true if the AVL invariant holds, false otherwise
     */
    public boolean isBalanced() {
        return isBalancedRec(root);
    }

    private boolean isBalancedRec(AVLNode<T> node) {
        if (node == null) return true;
        int bf = balanceFactor(node);
        if (Math.abs(bf) > 1) return false;
        return isBalancedRec(node.left) && isBalancedRec(node.right);
    }

    // ─────────────────────────────────────────────────────────
    // METRICS HELPERS
    // ─────────────────────────────────────────────────────────

    /** @return total comparisons made since construction */
    public int getComparisons()  { return comparisons;  }

    /** @return number of LL rotations performed */
    public int getRotationsLL()  { return rotationsLL;  }

    /** @return number of RR rotations performed */
    public int getRotationsRR()  { return rotationsRR;  }

    /** @return number of LR rotations performed */
    public int getRotationsLR()  { return rotationsLR;  }

    /** @return number of RL rotations performed */
    public int getRotationsRL()  { return rotationsRL;  }

    /** @return total rotations of all types */
    public int getTotalRotations() {
        return rotationsLL + rotationsRR + rotationsLR + rotationsRL;
    }

    /** Resets comparison and rotation counters to zero. */
    public void resetCounters() {
        comparisons = 0;
        rotationsLL = 0;
        rotationsRR = 0;
        rotationsLR = 0;
        rotationsRL = 0;
    }

    /** @return true if the tree is empty */
    public boolean isEmpty() { return root == null; }
}