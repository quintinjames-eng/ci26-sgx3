package tree;

/**
 * A single node in a Binary Search Tree.
 * Holds a comparable key and references to left and right children.
 *
 * @param <T> the type of key stored, must be Comparable
 */
public class BSTNode<T extends Comparable<T>> {

    /** The value stored in this node. */
    T key;

    /** Left child — holds keys smaller than this node's key. */
    BSTNode<T> left;

    /** Right child — holds keys greater than this node's key. */
    BSTNode<T> right;

    /**
     * Constructs a new leaf node with the given key.
     * Left and right children are null by default.
     * @param key the value to store in this node
     */
    public BSTNode(T key) {
        this.key   = key;
        this.left  = this.right = null;
    }
}