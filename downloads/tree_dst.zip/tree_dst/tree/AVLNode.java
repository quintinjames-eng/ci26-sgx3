package tree;

/**
 * A single node in an AVL Tree.
 * Extends the BST node concept by storing the node's height,
 * which is used to compute balance factors during rebalancing.
 *
 * @param <T> the type of key stored, must be Comparable
 */
public class AVLNode<T extends Comparable<T>> {

    /** The value stored in this node. */
    T key;

    /** Left child — holds keys smaller than this node's key. */
    AVLNode<T> left;

    /** Right child — holds keys greater than this node's key. */
    AVLNode<T> right;

    /**
     * The height of this node.
     * A leaf node has height 0. A null node is treated as height -1.
     */
    int height;

    /**
     * Constructs a new leaf AVL node with the given key.
     * Height starts at 0 since a new node is always a leaf.
     * @param key the value to store in this node
     */
    public AVLNode(T key) {
        this.key = key;
        this.left = this.right = null;
        this.height = 0;
    }
}